<link rel="icon" type="image/png" href="<?php echo e(asset('pwa/assets/img/favicon.png')); ?>" sizes="32x32">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('pwa/assets/img/icon/192x192.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('pwa/assets/css/style.css')); ?>">

<script src="<?php echo e(asset('fontawesome/js/all.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('sweetalert/sweetalert2.css')); ?>">
<script src="<?php echo e(asset('sweetalert/sweetalert2.min.js')); ?>"></script>

<link rel="stylesheet" href="<?php echo e(asset('select2/css/select2.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('select2/js/select2.min.js')); ?>"></script>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/pwa/head-tag.blade.php ENDPATH**/ ?>