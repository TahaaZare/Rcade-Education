<?php $__env->startSection('title', 'قوانین در خواست مدرس'); ?>
<?php $__env->startSection('app-menu'); ?>
    <?php echo $__env->make('pwa.app-button-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('pwa.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card p-4">
            <div class="d-flex justify-content-between">
                <div class="">
                    <h3> قوانین در خواست مدرس
                    </h3>
                </div>
            </div>
            <hr>
            <div class="accordion" id="accordionExample3">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#accordion-<?php echo e($Rule->id); ?>">
                            <span class="fas fa-check-circle text-success mx-2"></span>
                            قوانین در خواست مدرس
                        </button>
                    </h2>
                    <div id="accordion-<?php echo e($Rule->id); ?>" class="accordion-collapse collapse"
                        data-bs-parent="#accordionExample3">
                        <div class="accordion-body">
                            <?php echo $Rule->description; ?>

                            <div class="p-3 d-inline-flex bg-transparent">
                                <a href="<?php echo e(route('admin.rule.edit', [$user->username, $Rule])); ?>"
                                    class="btn btn-warning mx-2 rounded">ویرایش</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pwa.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/admin/content/master-rule/index.blade.php ENDPATH**/ ?>