<div class="home-four-course edu-course-area course-area-4 gap-tb-text bg-image">
    <div class="container edublink-animated-shape">
        <div class="section-title section-center" data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">
            <span class="pre-title">دوره‌های محبوب</span>
            <h2 class="title">برای شروع یک دوره انتخاب کنید</h2>
            <span class="shape-line"><i class="icon-19"></i></span>
        </div>
        <div class="row g-5">
            <!-- Start Single Course  -->
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-6" data-sal-delay="100" data-sal="slide-up" data-sal-duration="800">
                    <div class="edu-course course-style-4">
                        <div class="inner">
                            <div class="thumbnail">
                                <a href="<?php echo e(route('show-course', $item->slug)); ?>">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->name); ?>">
                                </a>
                            </div>
                            <div class="content">
                                <div class="course-price">
                                    <?php if($item->price == 0): ?>
                                        <span class="text-success">
                                            رایگانــ
                                        </span>
                                    <?php else: ?>
                                        <span class="text-primary">
                                            <?php echo e(priceFormatToPersian($item->price)); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <h6 class="title">
                                    <a href="<?php echo e(route('show-course', $item->slug)); ?>">
                                        <?php echo e($item->name); ?></a>
                                </h6>
                                <div class="course-rating">
                                    <div class="rating">
                                        <i class="icon-23"></i>
                                        <i class="icon-23"></i>
                                        <i class="icon-23"></i>
                                        <i class="icon-23"></i>
                                        <i class="icon-23"></i>
                                    </div>
                                    
                                </div>
                                <ul class="course-meta">
                                    <li class="d-flex"><i class="icon-24"></i>0 درس</li>
                                    <li class="d-flex"><i class="icon-25"></i>0 دانشجو</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Single Course  -->
        </div>
        <div class="course-view-all" data-sal-delay="150" data-sal="slide-up" data-sal-duration="1200">
            <a href="<?php echo e(route('courses')); ?>" class="edu-btn">دوره‌های بیشتر <i class="icon-west"></i></a>
        </div>
        <ul class="shape-group">
            <li class="shape-1 scene" data-sal-delay="500" data-sal="fade" data-sal-duration="200">
                <img data-depth="-2" src="<?php echo e(asset('site-assets/assets/images/about/shape-13.png')); ?>" alt="Shape">
            </li>
            <li class="shape-2 scene" data-sal-delay="500" data-sal="fade" data-sal-duration="200">
                <span data-depth="1"></span>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/layouts/course-area.blade.php ENDPATH**/ ?>