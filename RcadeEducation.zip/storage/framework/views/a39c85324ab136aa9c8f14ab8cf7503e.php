<?php $__env->startSection('title', "دوره : $course->name"); ?>
<?php $__env->startSection('content'); ?>
    <div class="edu-breadcrumb-area breadcrumb-style-6">
        <div class="container">
            <div class="breadcrumb-inner">
                <div class="page-title">
                    <h2 class="title">
                        <?php echo e($course->name); ?>

                    </h2>
                </div>
                <ul class="course-meta">
                    <li><i class="icon-58"></i>
                        <?php echo e($course->master->username); ?>

                    </li>
                    <li><i class="icon-59"></i>فارسی</li>
                </ul>
            </div>
        </div>
        <ul class="shape-group">
            <li class="shape-1">
                <span></span>
            </li>
            <li class="shape-2 scene"
                style="transform: translate3d(0px, 0px, 0px) rotate(0.0001deg); transform-style: preserve-3d; backface-visibility: hidden; pointer-events: none;">
                <img data-depth="2" src="<?php echo e(asset('site-assets/assets/images/others/shape-79.png')); ?>" alt="shape"
                    style="transform: translate3d(-30.9px, 21.4px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: relative; display: block; left: 0px; top: 0px;">
            </li>
            <li class="shape-3 scene"
                style="transform: translate3d(0px, 0px, 0px) rotate(0.0001deg); transform-style: preserve-3d; backface-visibility: hidden; pointer-events: none;">
                <img data-depth="-2" src="<?php echo e(asset('site-assets/assets/images/about/shape-15.png')); ?>" alt="shape"
                    style="transform: translate3d(20px, -5.3px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: relative; display: block; left: 0px; top: 0px;">
            </li>
            <li class="shape-4">
                <span></span>
            </li>
            <li class="shape-5 scene"
                style="transform: translate3d(0px, 0px, 0px) rotate(0.0001deg); transform-style: preserve-3d; backface-visibility: hidden; pointer-events: none;">
                <img data-depth="2" src="<?php echo e(asset('site-assets/assets/images/about/shape-07.png')); ?>" alt="shape"
                    style="transform: translate3d(-24.4px, 26px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: relative; display: block; left: 0px; top: 0px;">
            </li>
        </ul>
    </div>
    <section class="edu-section-gap course-details-area">
        <div class="container">
            <div class="row row--30">
                <div class="col-lg-8">
                    <div class="course-details-content course course-details-4">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" href="#overview-tab-id">نمای کلی</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" href="#instructor-tab-id">مدرس</a>
                            </li>
                        </ul>

                        <div class="course-content-wrapper">
                            <div class="tab-pane" id="overview-tab-id">
                                <div class="course-tab-content">
                                    <div class="course-overview">
                                        <h3 class="heading-title">توضیحات دوره</h3>
                                        <?php echo $course->description; ?>

                                    </div>
                                </div>
                                <div class="course-curriculam mb--90">
                                    <div class="accordion edu-accordion sal-animate" id="accordionExample"
                                        data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">
                                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="accordion-item shadow" style="border-radius: 1rem">
                                                <h3 class="accordion-header" id="heading<?php echo e($session->id); ?>">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse"
                                                        data-bs-target="#collapse-<?php echo e($session->id); ?>" aria-expanded="true"
                                                        aria-controls="collapse-<?php echo e($session->id); ?>">
                                                        <?php echo e($session->name); ?>

                                                    </button>
                                                </h3>
                                                <div id="collapse-<?php echo e($session->id); ?>" class="accordion-collapse collapse"
                                                    aria-labelledby="heading<?php echo e($session->id); ?>"
                                                    data-bs-parent="#accordionExample" style="">
                                                    <div class="accordion-body">
                                                        <div class="course-lesson">
                                                            <ul>
                                                                <?php $__currentLoopData = $episodes[$session->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li>
                                                                        <div class="text"><i class="icon-65"></i>
                                                                            <?php echo e($episode->name); ?></div>
                                                                        <span>
                                                                            نوع فایل: <?php echo e($episode->file_type); ?>

                                                                        </span>
                                                                        <span>
                                                                            حجم فایل:
                                                                            <?php echo e(formatBytes($episode->file_size)); ?>

                                                                        </span>
                                                                        <a href="<?php echo e(asset($episode->file_path)); ?>"
                                                                            download>
                                                                            <i class="fas fa-download"></i>
                                                                            دانلود
                                                                        </a>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane">
                                <div class="course-tab-content" id="instructor-tab-id">
                                    <div class="course-instructor">
                                        <div class="thumbnail">
                                            <img src="<?php echo e(asset($course->master->profile)); ?>"
                                                class="rounded rounded-circle shadow w-75"
                                                alt="<?php echo e($course->master->username); ?>">
                                        </div>
                                        <div class="author-content">
                                            <h6 class="title">
                                                <?php echo e($course->master->display_name ?? $course->master->username); ?></h6>
                                            <?php echo $course->master->bio; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane">
                                <div class="course-tab-content">
                                    <div class="course-review" id="review-tab-id">
                                        <div class="row g-0 align-items-center">
                                            <div class="col-sm-8">
                                                <!-- Start Comment Area  -->
                                                <div class="comment-area">
                                                    <h3 class="heading-title">نظرات</h3>
                                                    <div class="comment-list-wrapper">
                                                        <div class="comment-area">
                                                            <div class="comment-list-wrapper">
                                                                <div class="comment">
                                                                    <p class="alert alert-info rounded text-center">
                                                                        در حال حاضر نمیتوان کامنت گذاشت
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="course-sidebar-3 sidebar-top-position">
                        <div class="edu-course-widget widget-course-summery">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo e(asset($course->image)); ?>" alt="Courses">
                                    
                                </div>
                                <div class="content">
                                    <h4 class="widget-title">دوره شامل:</h4>
                                    <ul class="course-item">
                                        <li>
                                            <span class="label"><i class="icon-60"></i>قیمت:</span>
                                            <span class="value price">
                                                <?php if($course->price == 0): ?>
                                                    رایگانـ
                                                <?php else: ?>
                                                    <?php echo e(priceFormatToPersian($course->price)); ?>

                                                <?php endif; ?>
                                            </span>
                                        </li>
                                        <li>
                                            <span class="label"><i class="icon-63"></i>وضعیت دوره :</span>
                                            <span class="value">
                                                <?php if($course->course_status == 0): ?>
                                                    به زودی . . .
                                                <?php elseif($course->course_status == 1): ?>
                                                    در حال ظبط
                                                <?php elseif($course->course_status == 2): ?>
                                                    در حال برگزاری
                                                <?php elseif($course->course_status == 3): ?>
                                                    به اتمام رسیده
                                                <?php endif; ?>
                                            </span>
                                        </li>
                                        <li>
                                            <span class="label"><i class="icon-62"></i>مدرس:</span>
                                            <span class="value">
                                                <?php echo e($course->master->display_name ?? $course->master->username); ?>

                                            </span>
                                        </li>

                                        <li>
                                            <span class="label"><i class="icon-63"></i>دانشجو :</span>
                                            <span class="value">0</span>
                                        </li>
                                    </ul>
                                    <div class="read-more-btn">
                                        <a href="#" class="edu-btn">الان شروع کنید <i class="icon-west"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/content/course/show-course.blade.php ENDPATH**/ ?>