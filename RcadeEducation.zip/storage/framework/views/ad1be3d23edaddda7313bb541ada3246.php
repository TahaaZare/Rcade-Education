<?php if(session('swal-warning')): ?>

    <script>
        $(document).ready(function (){
            Swal.fire({
                title: 'هشدار !',
                 text: '<?php echo e(session('swal-warning')); ?>',
                 icon: 'warning',
                 confirmButtonText: 'باشه',
      });
        });
    </script>

<?php endif; ?>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/alerts/sweetalert/warning.blade.php ENDPATH**/ ?>