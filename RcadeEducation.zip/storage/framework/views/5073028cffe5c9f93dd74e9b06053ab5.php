<div id="edublink-preloader">
    <div class="loading-spinner">
        <div class="preloader-spin-1"></div>
        <div class="preloader-spin-2"></div>
    </div>
    
</div><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/layouts/loader.blade.php ENDPATH**/ ?>