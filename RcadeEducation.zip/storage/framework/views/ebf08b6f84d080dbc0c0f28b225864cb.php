 <!-- Favicon -->
 <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('site-assets/assets/images/logo/logo.png')); ?>">
 <!-- CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/bootstrap.rtl.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/icomoon.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/remixicon.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/magnifypopup.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/odometer.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/lightbox.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/animation.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/jqueru-ui-min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/swiper-bundle.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/vendor/tipped.min.css')); ?>">

 <!-- Site Stylesheet -->
 <link rel="stylesheet" href="<?php echo e(asset('site-assets/assets/css/app.css?v=3')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('sweetalert/sweetalert2.css')); ?>">
 <script src="<?php echo e(asset('sweetalert/sweetalert2.min.js')); ?>"></script>

 <script src="<?php echo e(asset('fontawesome/js/all.min.js')); ?>"></script>
 <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.min.css')); ?>">
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/layouts/head-tag.blade.php ENDPATH**/ ?>