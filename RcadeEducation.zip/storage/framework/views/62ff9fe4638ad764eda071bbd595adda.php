<script src="<?php echo e(asset('jquery.min.js')); ?>"></script>
<!-- ============== Js Files ==============  -->
<!-- Bootstrap -->
<script src="<?php echo e(asset('pwa/assets/js/lib/bootstrap.min.js')); ?>"></script>
<!-- Ionicons -->
<script type="module" src="<?php echo e(asset('pwa/assets/js/ionicons/ionicons.js')); ?>"></script>
<!-- Splide -->
<script src="<?php echo e(asset('pwa/assets/js/plugins/splide/splide.min.js')); ?>"></script>
<!-- ProgressBar js -->
<script src="<?php echo e(asset('pwa/assets/js/plugins/progressbar-js/progressbar.min.js')); ?>"></script>
<!-- Base Js File -->
<script src="<?php echo e(asset('pwa/assets/js/base.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<script src="<?php echo e(asset('jquery.min.js')); ?>"></script>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/pwa/script.blade.php ENDPATH**/ ?>