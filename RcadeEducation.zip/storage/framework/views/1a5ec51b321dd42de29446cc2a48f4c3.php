<?php $__env->startSection('title', 'دوره ها'); ?>
<?php $__env->startSection('app-menu'); ?>
    <?php echo $__env->make('pwa.app-button-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('pwa.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card p-4">
            <div class="d-flex justify-content-between">
                <a class="btn btn-outline-secondary" href="<?php echo e(route('admin.course-category.index', $user->username)); ?>">دسته
                    بندی</a>
                <div class="">
                    <h3> دوره ها
                        <span class="badge bg-info mx-2"><?php echo e($courses->count()); ?></span>
                    </h3>
                </div>
                <a class="btn btn-outline-primary" href="<?php echo e(route('admin.course.create', $user->username)); ?>">افزودن</a>
            </div>
        </div>
        <hr>
        <div class="row">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12  py-3">
                    <div class="card product-card">
                        <div class="card-body">
                            <img src="<?php echo e(asset($item->image)); ?>" class="image" alt="<?php echo e($item->name); ?>">
                            <div class="d-flex justify-content-between">
                                <h2 class="title d-flex justify-content-center">
                                    <?php echo e($item->name); ?>

                                </h2>

                                <div class="dropdown">
                                    <button class="btn btn-transparent text-white-50 " type="button"
                                        data-bs-toggle="dropdown" aria-hidden="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-h fa-lg text-success"></i>
                                    </button>
                                    <div class="dropdown-menu " style="">
                                        <a href="<?php echo e(route('admin.course.edit', [$user->username, $item])); ?>"
                                            class="btn btn-sm btn-warning p-2 dropdown-item">
                                            ویرایش
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a href="<?php echo e(route('admin.course-sesson.index', [$user->username, $item])); ?>"
                                            class="btn btn-sm btn-primary p-2 dropdown-item">
                                            افزودن سرفصل جدید
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a href="<?php echo e(route('admin.course-episode.index', [$user->username, $item])); ?>"
                                            class="btn btn-sm btn-primary p-2 dropdown-item">
                                            افزودن ویدیو جدید
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <form action="<?php echo e(route('admin.course.delete', [$user->username, $item])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger dropdown-item">
                                                حذفــ </button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <h3 class="title d-flex justify-content-between">

                                <span class="badge bg-secondary rounded mx2">
                                    استاد : <?php echo e($item->master->username); ?>

                                </span>
                                <span class="badge bg-primary rounded mx2">
                                    <?php if($item->course_level == 0): ?>
                                        مقدماتی
                                    <?php elseif($item->course_level == 1): ?>
                                        معمولی
                                    <?php elseif($item->course_level == 2): ?>
                                        سخت
                                    <?php elseif($item->course_level == 3): ?>
                                        پیشرفته
                                    <?php endif; ?>
                                </span>
                                <span class="badge bg-info rounded mx2">
                                    <?php if($item->course_status == 0): ?>
                                        به زودی . . .
                                    <?php elseif($item->course_status == 1): ?>
                                        در حال ظبط
                                    <?php elseif($item->course_status == 2): ?>
                                        در حال برگزاری
                                    <?php elseif($item->course_status == 3): ?>
                                        به اتمام رسیده
                                    <?php endif; ?>
                                </span>
                                <?php if($item->status == 1): ?>
                                    <span class="badge bg-success rounded mx2">فعال</span>
                                <?php else: ?>
                                    <span class="badge bg-danger rounded mx2">غیرفعال</span>
                                <?php endif; ?>
                            </h3>
                            <br>
                            <div class="price">
                                ایجاد شده توسط : <?php echo e($item->user->username); ?> -
                                <?php echo e(jalaliDate($item->created_at)); ?>

                            </div>



                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pwa.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/admin/content/course/index.blade.php ENDPATH**/ ?>