<?php $__env->startSection('title', 'مقالات'); ?>
<?php $__env->startSection('app-menu'); ?>
    <?php echo $__env->make('pwa.app-button-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('pwa.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card p-4">
            <div class="d-flex justify-content-between">
                <a class="btn btn-outline-secondary" href="<?php echo e(route('admin.blog-category.index', $user->username)); ?>">دسته
                    بندی</a>
                <div class="">
                    <h3> مقالات
                        <span class="badge bg-info mx-2"><?php echo e($blogs->count()); ?></span>
                    </h3>
                </div>
                <a class="btn btn-outline-primary" href="<?php echo e(route('admin.blog.create', $user->username)); ?>">افزودن</a>
            </div>
        </div>
        <hr>
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="card product-card">
                        <div class="card-body">
                            <img src="<?php echo e(asset($item->image)); ?>" class="image" alt="<?php echo e($item->title); ?>">
                            <h2 class="title d-flex justify-content-between"><?php echo e($item->title); ?>

                                <?php if($item->status == 1): ?>
                                    <span class="badge bg-success rounded mx2">فعال</span>
                                <?php else: ?>
                                    <span class="badge bg-danger rounded mx2">غیرفعال</span>
                                <?php endif; ?>
                            </h2>
                            <p class="text">
                                توسط : <?php echo e($item->user($item->create_by)->username); ?>

                            </p>
                            <div class="price">
                                <?php echo e(jalaliDate($item->created_at)); ?>

                            </div>
                            <a href="<?php echo e(route('admin.blog.edit', [$user->username, $item])); ?>"
                                class="btn btn-sm btn-warning btn-block my-2">ویرایش</a>
                            <form action="<?php echo e(route('admin.blog.delete', [$user->username, $item])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger btn-block">
                                    حذفــ
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pwa.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/admin/content/blog/index.blade.php ENDPATH**/ ?>