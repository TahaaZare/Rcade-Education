<?php if(session('swal-success') && session('swal-title')): ?>
    <script>
        $(document).ready(function() {
            Swal.fire({
                title: '<?php echo e(session('swal-title')); ?>',
                text: '<?php echo e(session('swal-success')); ?>',
                icon: 'success',
                confirmButtonText: 'باشه',
            });
        });
    </script>
<?php elseif(session('swal-success')): ?>
    <script>
        $(document).ready(function() {
            Swal.fire({
                title: 'عملیات با موفقیت انجام شد',
                text: '<?php echo e(session('swal-success')); ?>',
                icon: 'success',
                confirmButtonText: 'باشه',
            });
        });
    </script>
<?php endif; ?>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/alerts/sweetalert/success.blade.php ENDPATH**/ ?>