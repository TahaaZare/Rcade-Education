<div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarPanel">
    <div class="offcanvas-body">
        <!-- profile box -->
        <?php if(auth()->guard()->check()): ?>
            <?php
                $user = auth()->user();
            ?>
            <div class="profileBox">
                <div class="image-wrapper">
                    <img src="<?php echo e(asset($user->profile)); ?>" alt="<?php echo e($user->username); ?>" class="imaged rounded">
                </div>
                <div class="in">
                    <strong aria-hidden="true">
                        <?php echo e($user->display_name ?? $user->username); ?>

                    </strong>
                </div>
                <a href="#" class="close-sidebar-button" data-bs-dismiss="offcanvas">
                    <ion-icon name="close">
                        <i class="fas fa-close text-dark"></i>
                    </ion-icon>
                </a>
            </div>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <div class="profileBox">
                <div class="in">
                    <a class="text-dark" href="<?php echo e(route('loginForm')); ?>">
                        ورود به با شماره تماس</a>
                </div>
                <a href="#" class="close-sidebar-button" data-bs-dismiss="offcanvas">
                    <ion-icon name="close">
                        <i class="fas fa-close text-dark"></i>
                    </ion-icon>
                </a>
            </div>
        <?php endif; ?>
        <!-- * profile box -->

        <ul class="listview flush transparent no-line image-listview mt-2">
            <li>
                <a href="<?php echo e(route('home')); ?>" class="item">
                    <div class="icon-box bg-primary">
                        <ion-icon name="home-outline">
                            <i class="fas fa-home" aria-hidden="true"></i>
                        </ion-icon>
                    </div>
                    <div class="in">
                        خانه
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('courses')); ?>" class="item">
                    <div class="icon-box bg-primary">
                        <ion-icon name="home-outline">
                            <i class="fas fa-user-graduate" aria-hidden="true"></i>
                        </ion-icon>
                    </div>
                    <div class="in">
                        دوره ها
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('blogs')); ?>" class="item">
                    <div class="icon-box bg-primary">
                        <ion-icon name="home-outline">
                            <i class="fas fa-newspaper" aria-hidden="true"></i>
                        </ion-icon>
                    </div>
                    <div class="in">
                        مقالات
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('about-us')); ?>" class="item">
                    <div class="icon-box bg-primary">
                        <ion-icon name="home-outline">
                            <i class="fas fa-user-friends" aria-hidden="true"></i>
                        </ion-icon>
                    </div>
                    <div class="in">
                        درباره مـا
                    </div>
                </a>
            </li>

            <?php if(auth()->guard()->check()): ?>
                <?php
                    $user = auth()->user();
                ?>
                <?php if($user->user_type == 2): ?>
                    <hr>
                    <li class="text-center">
                        <span class="badge bg-primary">
                            بخش ادمین
                        </span>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.course.index', $user->username)); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline">
                                    <i class="fas fa-user-graduate" aria-hidden="true"></i>
                                </ion-icon>
                            </div>
                            <div class="in">
                                بخش دوره ها
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.blog.index', $user->username)); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline">
                                    <i class="fas fa-newspaper" aria-hidden="true"></i>
                                </ion-icon>
                            </div>
                            <div class="in">
                                بخش مقالات
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.faq.index', $user->username)); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline">
                                    <i class="fas fa-question" aria-hidden="true"></i>
                                </ion-icon>
                            </div>
                            <div class="in">
                                سوالات متداول
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.about.index', $user->username)); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline">
                                    <i class="fas fa-user-friends" aria-hidden="true"></i>
                                </ion-icon>
                            </div>
                            <div class="in">
                                درباره مـا
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.rule.index', $user->username)); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline">
                                    <i class="fas fa-user-friends" aria-hidden="true"></i>
                                </ion-icon>
                            </div>
                            <div class="in">
                                قوانین ثبت مدرس
                            </div>
                        </a>
                    </li>
                    <hr>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
    <?php echo $__env->make('pwa.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/pwa/offcanvas.blade.php ENDPATH**/ ?>