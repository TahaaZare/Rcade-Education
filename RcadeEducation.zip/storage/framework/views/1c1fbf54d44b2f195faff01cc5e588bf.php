<div class="header-large-title">
    <h4 class="subtitle">آخرین مقالات</h4>
</div>
<div class="section full mt-3 mb-3">
    <!-- carousel multiple -->
    <div class="carousel-multiple splide splide--loop splide--rtl splide--draggable is-active" id="splide01"
        style="visibility: visible;">
        <div class="splide__track" id="splide01-track" style="padding-left: 16px; padding-right: 16px;">
            <ul class="splide__list" id="splide01-list" style="transform: translateX(2295px);">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="splide__slide splide__slide--clone" aria-hidden="true" tabindex="-1"
                        style="margin-left: 16px; width: 255px;">
                        <div class="card">
                            <a href="<?php echo e(route('show-blog', $item->slug)); ?>">
                                <img src="<?php echo e(asset($item->image)); ?>" class="card-img-top" alt="<?php echo e($item->title); ?>">
                                <div class="card-body pt-2">
                                    <h4 class="mb-0">
                                        <?php echo e($item->title); ?>

                                    </h4>

                                </div>
                                <a href="<?php echo e(route('user-profile', $item->user($item->user_id)->username)); ?>" target="_blank">
                                    <div class="chip chip-media mx-2 my-1">
                                        <img src="<?php echo e(asset($item->user($item->user_id)->profile)); ?>" alt="avatar">
                                        <span class="chip-label">
                                            <?php echo e($item->user($item->user_id)->display_name ?? $item->user($item->user_id)->username); ?>

                                        </span>
                                    </div>
                                </a>
                            </a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <!-- * carousel multiple -->

</div>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/pwa/latest-blog.blade.php ENDPATH**/ ?>