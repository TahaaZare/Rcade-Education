<div class="edu-blog-area blog-area-3 edu-section-gap">
    <div class="container">
        <div class="section-title section-center" data-sal-delay="50" data-sal="slide-up" data-sal-duration="800">
            <h2 class="title">آخرین مقالات</h2>
            <span class="shape-line"><i class="icon-19"></i></span>
        </div>
        <div class="row g-5">
            <!-- Start Blog Grid  -->
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <div class="col-lg-4 col-md-6 col-12 sal-animate sha" data-sal-delay="100" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="edu-blog blog-style-1 programming-sytle">
                        <div class="inner">
                            <div class="thumbnail">
                                <a href="<?php echo e(route('show-blog',$item->slug)); ?>">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->title); ?>">                                </a>
                            </div>
                            <div class="content">
                                <div class="category-wrap">
                                    <a href="#" class="blog-category"><?php echo e($item->category->name); ?></a>
                                </div>
                                <h5 class="title"><a href="<?php echo e(route('show-blog',$item->slug)); ?>"><?php echo e($item->title); ?></a></h5>
                                <ul class="blog-meta">
                                    <li class="d-flex"><i class="icon-27"></i><?php echo e(jalaliShamsiDate($item->created_at)); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Blog Grid  -->
        </div>
    </div>
</div>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/layouts/blog-area.blade.php ENDPATH**/ ?>