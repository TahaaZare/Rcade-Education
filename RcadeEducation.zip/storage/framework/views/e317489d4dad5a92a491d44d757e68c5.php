<div class="section full mt-2 container shadow" style="border-radius: 1rem">
    <div class="section-title">سوالات متداول</div>
    <div class="accordion"  style="border-radius: 1rem" id="accordionExample1">
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion-item" >
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#accordion-<?php echo e($item->id); ?>" aria-expanded="false">
                        <?php echo e($item->question); ?>

                    </button>
                </h2>
                <div id="accordion-<?php echo e($item->id); ?>" class="accordion-collapse collapse" data-bs-parent="#accordionExample1"
                    style="">
                    <div class="accordion-body">
                        <?php echo $item->answer; ?>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/pwa/faq.blade.php ENDPATH**/ ?>