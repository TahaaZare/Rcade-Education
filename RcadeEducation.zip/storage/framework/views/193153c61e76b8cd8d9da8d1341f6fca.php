<!-- JS -->
<!-- Modernizer JS -->
<script src="<?php echo e(asset('site-assets/assets/js/vendor/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/sal.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/jquery.waypoints.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/backtotop.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/magnifypopup.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/jQuery.rProgressbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/easypie.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/isotop.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/imageloaded.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/lightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/paralax.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/paralax-scroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/svg-inject.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/vivus.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/tipped.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/smooth-scroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('site-assets/assets/js/vendor/isInViewport.jquery.min.js')); ?>"></script>

<!-- Site Scripts -->
<script src="<?php echo e(asset('site-assets/assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('jquery.min.js')); ?>"></script><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/layouts/script.blade.php ENDPATH**/ ?>