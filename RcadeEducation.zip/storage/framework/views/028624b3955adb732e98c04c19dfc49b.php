<div class="section full mb-3">
    <!-- carousel single -->
    <div class="carousel-single splide splide--loop splide--rtl splide--draggable is-active" id="splide02"
        style="visibility: visible;">
        <div class="splide__track" id="splide02-track" style="padding-left: 16px; padding-right: 16px;">
            <ul class="splide__list" id="splide02-list" style="transform: translateX(2762.59px);">
                <li class="splide__slide splide__slide--clone" aria-hidden="true" tabindex="-1"
                    style="margin-left: 16px; width: 345.333px">
                    <a href="https://ums.rcade.ir" target="_blank">
                        <img src="<?php echo e(asset('static-img/photo11594331633.jpg')); ?>" alt="alt" style="height: 250px;"
                            class="imaged w-100"></a>

                </li>
            </ul>
        </div>
    </div>
    <!-- * carousel single -->
</div>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/pwa/carousel.blade.php ENDPATH**/ ?>