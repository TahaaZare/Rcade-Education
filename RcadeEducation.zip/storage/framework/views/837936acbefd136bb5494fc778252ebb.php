<?php $__env->startSection('title', 'قسمت ها'); ?>

<?php $__env->startSection('app-menu'); ?>
    <?php echo $__env->make('pwa.app-button-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('pwa.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card p-4">
            <div class="d-flex justify-content-between">
                <div class="">
                    <h3>
                        قسمت ها
                        <span class="badge bg-info mx-2"><?php echo e($episodes->count()); ?></span>
                    </h3>
                </div>
                <a class="btn btn-outline-primary"
                    href="<?php echo e(route('admin.course-episode.create', [$user->username, $course, $sesson])); ?>">افزودن</a>
            </div>
            <hr>
            <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion" id="accordionExample3">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#accordion-<?php echo e($item->id); ?>">
                                <span class="fas fa-check-circle text-success mx-2"></span>
                                <?php echo $item->name; ?> ( دوره <?php echo e($item->course($item->course_id)->name); ?>)

                                <?php if($item->status == 1): ?>
                                    <span class="badge bg-success rounded mx-2">تایید شده</span>
                                <?php elseif($item->status == 0): ?>
                                    <span class="badge bg-primary rounded mx-2">در انتظار تایید . . .</span>
                                <?php else: ?>
                                    <span class="badge bg-danger rounded mx-2">رد شده !</span>
                                <?php endif; ?>
                            </button>
                        </h2>
                        <div id="accordion-<?php echo e($item->id); ?>" class="accordion-collapse collapse"
                            data-bs-parent="#accordionExample3">
                            توضیحات : <?php echo $item->description; ?>

                            <hr>
                            <span>
                                نوع فایل : <?php echo e($item->file_type); ?>

                                <br>
                                حجم فایل : <?php echo e(formatBytes($item->file_size)); ?>

                                <br>

                            </span>
                            <div class="accordion-body">
                                <div class="p-3 d-inline-flex justify-content-center bg-transparent">
                                    <a href="<?php echo e(route('admin.course-episode.edit', [$user->username, $course, $sesson, $item])); ?>"
                                        class="btn btn-warning mx-2 rounded">ویرایش</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pwa.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/admin/content/course/episode/index.blade.php ENDPATH**/ ?>