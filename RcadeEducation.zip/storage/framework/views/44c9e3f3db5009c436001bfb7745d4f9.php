<?php $__env->startSection('title', 'دسته بندی مقالات'); ?>
<?php $__env->startSection('app-menu'); ?>
    <?php echo $__env->make('pwa.app-button-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('pwa.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card p-4">
            <div class="d-flex justify-content-between">
                <div class="">
                    <h3>دسته بندی مقالات
                        <span class="badge bg-info mx-2"><?php echo e($categories->count()); ?></span>
                    </h3>
                </div>
                <a class="btn btn-outline-primary"
                    href="<?php echo e(route('admin.blog-category.create', $user->username)); ?>">افزودن</a>
            </div>
            <hr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion" id="accordionExample3">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#accordion-<?php echo e($item->id); ?>">
                                <span class="fas fa-check-circle text-success mx-2"></span>
                                <?php echo $item->name; ?>

                            </button>
                        </h2>
                        <div id="accordion-<?php echo e($item->id); ?>" class="accordion-collapse collapse"
                            data-bs-parent="#accordionExample3">
                            <div class="accordion-body">
                                <div class="p-3 d-inline-flex bg-transparent">
                                    <a href="<?php echo e(route('admin.blog-category.edit', [$user->username, $item])); ?>"
                                        class="btn btn-warning mx-2 rounded">ویرایش</a>
                                    <form
                                        action="<?php echo e(route('admin.blog-category.delete', [$user->username, $item])); ?>"method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn  mx-2 btn-danger rounded">
                                            حذفــ
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pwa.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/admin/content/blog/category/index.blade.php ENDPATH**/ ?>