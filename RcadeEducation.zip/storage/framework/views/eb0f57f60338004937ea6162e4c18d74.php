<?php $__env->startSection('title', "$blog->title"); ?>
<?php $__env->startSection('head-tag'); ?>
    <meta property=og:site_name value="Rcade Education">
    <meta property=og:title content="<?php echo e($blog->name); ?>">
    <meta property=og:url content="<?php echo e(route('show-blog', $blog->slug)); ?>" />
    <meta property=og:image content="<?php echo e(asset($blog->image)); ?>">
    <meta property=og:image:url content="<?php echo e(asset($blog->image)); ?>" />
    <meta property=og:image:width content="700">
    <meta property=og:image:type content="image/jpg">
    <meta property=og:description content="">
    <meta property=og:price:currency content="IRR">
    <meta property=og:locale content="ir_FA">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="blog-details-area section-gap-equal">
        <div class="container">
            <div class="row row--30">
                <div class="col-12">
                    <div class="blog-details-content">
                        <div class="entry-content">
                            <span class="category"><?php echo e($blog->category->name); ?></span>
                            <span class="category"><?php echo e($blog->visitLogs()->count()); ?></span>
                            <h3 class="title"><?php echo e($blog->title); ?></h3>
                            <ul class="blog-meta">
                                <li class="d-flex"><i class="icon-27"></i>
                                    <?php echo e(jalaliAgo($blog->created_at)); ?>

                                </li>
                            </ul>
                            <div class="thumbnail">
                                <img src="<?php echo e(asset($blog->image)); ?>" alt="Blog Image">
                            </div>
                        </div>
                        <div class="container">
                            <?php echo $blog->description; ?>

                        </div>
                    </div>

                    <div class="blog-author">
                        <div class="thumbnail">
                            <a href="<?php echo e(route('user-profile', $blog->user($blog->user_id)->username)); ?>">
                                <img class="shadow" src="<?php echo e(asset($blog->user($blog->user_id)->profile)); ?>"
                                    alt="<?php echo e($blog->user($blog->user_id)->username); ?>">
                            </a>
                        </div>
                        <div class="author-content">
                            <a href="<?php echo e(route('user-profile', $blog->user($blog->user_id)->username)); ?>">
                                <h5 class="title">
                                    <?php echo e($blog->user($blog->user_id)->username); ?></h5>
                            </a>
                            <div class="container">
                                <?php echo $blog->user($blog->user_id)->bio; ?>

                            </div>
                            <ul class="social-share icon-transparent">
                                <li>
                                    <a href="#"><i class="icon-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="icon-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="icon-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="blog-pagination">
                        <div class="row g-5">

                            <?php if($other_blogs->count() > 0): ?>
                                <?php $__currentLoopData = $other_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-6">
                                        <div class="blog-pagination-list prev-post">
                                            <a href="<?php echo e(route('show-blog', $item->slug)); ?>">
                                                <i class="icon-east"></i>
                                                <span><?php echo e($item->title); ?></span>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="col-lg-12">
                                    <p class="alert shadow alert-info rounded text-center">
                                        آیتمی برای نمایش یافت نشد !
                                    </p>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/content/blog/show-blog.blade.php ENDPATH**/ ?>