<meta charset="utf-8">
<!-- Meta Data -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?php echo $__env->yieldContent('title', $setting->title ?? "سایت آموزشی Rcade"); ?></title>
<link rel="canonical" href="<?php echo e(url()->current()); ?>" />
<meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', $setting->meta_key ?? "سامانه مدیریت دانشگاهی,سایت آموزشی Rcade"); ?>">
<meta name="description" content="<?php echo $__env->yieldContent('meta_description', $setting->meta_description ?? "سامانه مدیریت دانشگاهی,سایت آموزشی Rcade"); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/layouts/meta.blade.php ENDPATH**/ ?>