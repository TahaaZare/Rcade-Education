<!-- sidebar buttons -->
<div class="sidebar-buttons">
    <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('user.logout')); ?>" class="button">
            <i class="fas fa-sign-out-alt" aria-hidden="true"></i>
        </a>
    <?php endif; ?>
</div>
<?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/pwa/sidebar.blade.php ENDPATH**/ ?>