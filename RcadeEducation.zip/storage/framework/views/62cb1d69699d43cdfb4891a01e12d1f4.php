<?php $__env->startSection('title', "پروفایل $user->username"); ?>
<?php $__env->startSection('app-menu'); ?>
    <?php echo $__env->make('pwa.app-button-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('pwa.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="section mt-2">
        <div class="profile-head">
            <div class="avatar">
                <img src="<?php echo e(asset($user->profile)); ?>" alt="avatar" class="imaged shadow w64 rounded">
            </div>
            <div class="in">
                <h3 class="name"><?php echo e($user->display_name ?? '-'); ?></h3>
                <h5 class="subtext" dir="ltr">
                    <?php
                        $username = "@$user->username";
                    ?>
                    <?php echo e($username); ?>

                </h5>

            </div>
        </div>
    </div>
    <?php if(auth()->guard()->check()): ?>
        <?php
            $auth_user = auth()->user();
        ?>
        <?php if($auth_user->username != $user->username): ?>
            <a href="<?php echo e(route('follow-user', [$auth_user->username, $user->username])); ?>" class="btn btn-primary rounded m-2">
                دنبال کردن
            </a>
        <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('loginForm')); ?>" class="btn btn-primary rounded m-2">
            دنبال کردن
        </a>
    <?php endif; ?>

    <div class="section full mt-2">
        <div class="profile-stats ps-2 pe-2">
            <a href="#" class="item">
                <strong><?php echo e($user_blogs->count()); ?></strong>مقالات
            </a>

        </div>
    </div>

    <div class="section mt-1 mb-2">
        <div class="profile-info">
            <div class="bio in">
                <?php echo $user->bio ?? 'بیوگرافی وارد نشده '; ?>

            </div>
        </div>
    </div>

    <div class="section full">
        <div class="wide-block transparent p-0">
            <ul class="nav nav-tabs lined iconed" role="tablist">
                <li class="nav-item ">
                    <a class="nav-link active" data-bs-toggle="tab" href="#feed" role="tab" aria-selected="false">
                        <i class="fas fa-newspaper fa-lg"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- tab content -->
    <div class="section full mb-2">
        <div class="tab-content">

            <!-- feed -->
            <div class="tab-pane fade show active" id="feed" role="tabpanel">
                <div class="mt-2 p-2 pt-0 pb-0">
                    <div class="row">
                        <?php $__currentLoopData = $user_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-4 mb-2">
                                <a data-bs-toggle="offcanvas" href="#offcanvas-bottom-<?php echo e($item->id); ?>">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="image" class="imaged h-50 w-100">
                                </a>
                                <div class="offcanvas offcanvas-bottom" tabindex="-1"
                                    id="offcanvas-bottom-<?php echo e($item->id); ?>">
                                    <div class="offcanvas-header">
                                        <div class="d-flex justify-content-center">
                                            <h5 class="offcanvas-title">مقاله : <?php echo e($item->title); ?></h5>
                                        </div>
                                        <a href="#" class="offcanvas-close" data-bs-dismiss="offcanvas">
                                            <ion-icon name="close-outline"></ion-icon>
                                        </a>
                                    </div>
                                    <div class="offcanvas-body">
                                        <div>
                                            <?php echo Str::limit($item->description, $limit = 300, $end = ' . . . '); ?>

                                        </div>
                                        <hr>
                                        <div class="d-flex justify-content-start">
                                            <a href="<?php echo e(route('show-blog', $item->slug)); ?>"
                                                class="btn btn-outline-warning mx-1">مشاهده</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <!-- * feed -->
        </div>
    </div>
    <!-- * tab content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('ckeditor5/build/ckeditor.js')); ?>"></script>
    <script>
        const watchdog = new CKSource.EditorWatchdog();
        window.watchdog = watchdog;
        watchdog.setCreator((element, config) => {
            return CKSource.Editor
                .create(element, config)
                .then(editor => {
                    return editor;
                })
        });

        watchdog.setDestructor(editor => {
            return editor.destroy();
        });

        watchdog.on('error', handleError);

        watchdog
            .create(document.querySelector('.description'), {
                licenseKey: '',
            })
            .catch(handleError);

        function handleError(error) {
            console.error(error);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pwa.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB\BACK-END\Laravel\RcadeEducation\resources\views/site/account/user-profile.blade.php ENDPATH**/ ?>