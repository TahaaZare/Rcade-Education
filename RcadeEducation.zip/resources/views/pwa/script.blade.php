<script src="{{ asset('jquery.min.js') }}"></script>
<!-- ============== Js Files ==============  -->
<!-- Bootstrap -->
<script src="{{ asset('pwa/assets/js/lib/bootstrap.min.js') }}"></script>
<!-- Ionicons -->
<script type="module" src="{{ asset('pwa/assets/js/ionicons/ionicons.js') }}"></script>
<!-- Splide -->
<script src="{{ asset('pwa/assets/js/plugins/splide/splide.min.js') }}"></script>
<!-- ProgressBar js -->
<script src="{{ asset('pwa/assets/js/plugins/progressbar-js/progressbar.min.js') }}"></script>
<!-- Base Js File -->
<script src="{{ asset('pwa/assets/js/base.js') }}"></script>

<script type="text/javascript" src="{{ asset('vendor/jsvalidation/js/jsvalidation.js')}}"></script>
<script src="{{ asset('jquery.min.js') }}"></script>
