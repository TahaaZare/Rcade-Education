<link rel="icon" type="image/png" href="{{ asset('pwa/assets/img/favicon.png') }}" sizes="32x32">
<link rel="apple-touch-icon" sizes="180x180" href="{{ asset('pwa/assets/img/icon/192x192.png') }}">
<link rel="stylesheet" href="{{ asset('pwa/assets/css/style.css') }}">

<script src="{{ asset('fontawesome/js/all.min.js') }}"></script>
<link rel="stylesheet" href="{{ asset('fontawesome/css/all.min.css') }}">
<link rel="stylesheet" href="{{ asset('sweetalert/sweetalert2.css') }}">
<script src="{{ asset('sweetalert/sweetalert2.min.js') }}"></script>

<link rel="stylesheet" href="{{ asset('select2/css/select2.min.css') }}">
<script type="text/javascript" src="{{ asset('select2/js/select2.min.js') }}"></script>
