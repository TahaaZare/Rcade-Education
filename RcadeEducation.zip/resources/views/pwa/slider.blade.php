<div class="wide-block p-0 pt-2 pb-2">
    <div class="carousel-single splide splide--loop splide--rtl splide--draggable is-active" id="splide02"
        style="visibility: visible;">
        <div class="splide__track" id="splide02-track" style="padding-left: 16px; padding-right: 16px;">
            <ul class="splide__list" id="splide02-list" style="transform: translateX(1388px);">
                <!-- Card item START -->
                <li class="splide__slide splide__slide--clone" style="margin-left: 16px; width: 694px;">
                    <img src="" alt="alt" class="imaged w-100">
                </li>

            </ul>
        </div>
    </div>


    <br>

    <br>
</div>
<br>
<div class="section full mb-3 my-4">
    <!-- carousel small -->
    <div class="d-flex justify-content-between">
        <h2 class="m-2">
            پست های پیشنهادی
        </h2>
        <span class="m-2" href="">
            <a class="text-warning" href="{{ route('explore') }}">
                بیشتر
            </a>
        </span>
    </div>

    <div class="carousel-small splide splide--loop splide--rtl splide--draggable is-active" id="splide04"
        style="visibility: visible;">
        <div class="splide__track" id="splide04-track" style="padding-left: 16px; padding-right: 16px;">
            <ul class="splide__list my-3" id="splide04-list" style="transform: translateX(1791.71px);">



            </ul>
        </div>
    </div>
    <!-- * carousel small -->
</div>
<br>
<div class="section full mb-3 my-4">
    <div class="d-flex justify-content-between">
        <h2 class="m-2">
            پست های پر بازدید
        </h2>
        <span class="m-2" href="">
            <a class="text-warning" href="{{ route('explore') }}">
                بیشتر
            </a>
        </span>
    </div>
    <!-- carousel small -->

    <div class="carousel-small splide splide--loop splide--rtl splide--draggable is-active" id="splide04"
        style="visibility: visible;">
        <div class="splide__track" id="splide04-track" style="padding-left: 16px; padding-right: 16px;">
            <ul class="splide__list my-3" id="splide04-list" style="transform: translateX(1791.71px);">

            </ul>
        </div>
    </div>
    <!-- * carousel small -->
</div>

<br>

